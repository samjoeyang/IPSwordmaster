---
name: ip-rights-audit
display_name: 权利核查与监测
display_name_en: IP Rights Audit & Monitoring
description: 知识产权权利基础核查与监测体系搭建。用于维权启动前的确权核查（专利/商标/著作权/商业秘密的有效性、权属、保护范围与剩余期限）、生成权利资产清单、办理知识产权海关保护备案、搭建电商平台/线下市场/展会/社媒的侵权监测体系。当用户准备维权、被侵权、需要盘点自有知识产权资产、要求"确权""权利清单""海关备案""侵权监测"时使用。Also usable in English when the user mentions IP rights audit, IP asset inventory, customs recordal, IP monitoring.
description_zh: 维权启动前的确权核查与监测体系搭建：核查专利/商标/著作权/商业秘密的有效性、权属、保护范围与剩余期限，生成权利资产清单，办理知识产权海关保护备案，搭建电商/线下/展会/社媒的侵权监测体系。
description_en: 'Pre-enforcement IP rights verification and monitoring: checks validity, ownership, scope and remaining term of patents/trademarks/copyrights/trade secrets; builds an asset inventory; files customs IP recordal; and sets up infringement monitoring across e-commerce, offline, trade-fair and social channels.'
version: 1.0.1
author: SamjoeYang - 上海不丁网络科技有限公司
license: MIT
agent_created: true
---

# 知识产权权利核查与监测（S0）

## Overview

在启动任何维权动作前，先确认"权利是否有效、归谁、保护什么、还剩多久"。本技能把确权核查、权利清单、海关备案与监测体系串成一条流水线，输出可直接支撑后续维权阶段（发现、比对、取证、诉讼）的权利基础材料。

## Workflow

1. **盘点权利资产**：询问/收集用户持有的知识产权凭证（专利证书及年费缴纳凭证、商标注册证及续展记录、著作权登记证书或创作底稿、商业秘密管理制度文件），列出全部权利项，不遗漏。
2. **有效性核查**：逐项核对权利状态与保护范围，详见 `references/rights-checklist.md`：
   - 专利：有效期（发明20年/实用新型10年/外观设计15年，自申请日起算）、年费是否缴纳、是否被无效宣告、权利要求当前文本。
   - 商标：有效期10年及续展状态、核定商品/服务类别、注册人名义与使用证据、是否连续三年未使用（撤三风险）。
   - 著作权：登记证书/创作底稿/首次发表记录、作品类型与权利内容（复制权、发行权、信息网络传播权等）。
   - 商业秘密：秘密性、价值性、保密措施"三要件"是否成立；密点分解与保密协议/制度文件是否齐备。
3. **生成权利清单**：输出结构化权利清单（权利类型、名称/号、权利人、有效期至、保护范围摘要、风险备注），作为后续所有维权环节的引用基础。权属有瑕疵（如共有、转让未登记、职务发明归属不清）时单独标注并提示先补正。
4. **办理海关备案（可选但推荐）**：对拟重点维权的商标权、专利权、著作权，指导在中国海关总署知识产权海关保护系统备案（权利人主体信息+权利证明+授权委托），备案后海关可依职权主动中止放行嫌疑货物。详见 `references/monitoring-channels.md` 中的海关章节。
5. **搭建监测体系**：按商品/服务与渠道特征配置监测：
   - 电商平台：淘天、京东、拼多多、抖音等关键词+图片检索，定期巡检。
   - 线下：目标市场、展会（展会期间重点排查）、批发市场。
   - 社媒/内容平台：小红书、微信、抖音、B站的仿冒推广。
   - 海关：进出口渠道（配合备案）。
   - 域名：与商标/商号近似的域名注册情况（用于后续 UDRP/CNNIC 争议程序）。
6. **输出监测台账**：记录渠道、关键词、巡检频率、负责人、发现记录，供 S1 阶段持续喂养线索。

## Output Standards

- 权利清单必须逐项标注有效期与风险，禁止把"权利已过期/已被无效"表述为有效。
- 所有结论区分"已核验（有凭证）"与"待补证（用户未提供）"，不得编造权利信息。
- 监测体系给出可执行的渠道+关键词+频率配置，而不是泛泛建议。

## Resources

- `references/rights-checklist.md`：四类权利核查要点与常见风险。
- `references/monitoring-channels.md`：监测渠道清单、海关备案流程、监测台账模板。

## 作者

本技能由 **知产刀客 · SamjoeYang** 设计并维护。
