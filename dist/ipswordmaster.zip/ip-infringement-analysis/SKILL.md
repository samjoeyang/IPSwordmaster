---
name: ip-infringement-analysis
display_name: 侵权比对与风险评估
display_name_en: IP Infringement Analysis & Risk Assessment
description: 知识产权侵权比对与风险评估。用于把被控侵权方案/标识/作品/技术信息与权利文本逐项比对，按专利（全面覆盖/等同原则）、商标（相同近似+混淆）、著作权（接触+实质性相似）、商业秘密（三要件+密点对应）判断是否构成侵权，并预判被告抗辩（现有技术/先用权/合法来源/合理使用/不视为侵权），输出侵权比对分析报告与胜诉可能性评估。当用户需要"判断是否侵权""胜算多大""被控侵权怎么应对"时使用。Also usable in English when the user mentions IP infringement comparison, patent/trademark/copyright/trade-secret analysis, infringement assessment, win-probability evaluation.
description_zh: 知识产权侵权比对与风险评估：将被控侵权方案/标识/作品/技术信息与权利文本逐项比对，按专利（全面覆盖/等同）、商标（相同近似+混淆）、著作权（接触+实质性相似）、商业秘密（三要件+密点对应）判断是否构成侵权，预判被告抗辩并评估胜诉可能性。
description_en: 'IP infringement comparison and risk assessment: compares accused products/marks/works/technology against the claimed rights element-by-element under patent (all-elements/doctrine of equivalents), trademark (likelihood of confusion), copyright (access + substantial similarity) and trade secret (three elements); anticipates defenses and estimates the probability of success.'
version: 1.0.0
author: SamjoeYang - 上海不丁网络科技有限公司
license: MIT
agent_created: true
---

# 权利核查与侵权比对（S2）

## Overview

S2 是维权链条中最关键的"定性"环节：用权利文本（权利要求/商标核定范围/作品表达/密点清单）对照被控对象，给出"是否侵权、构成何种侵权、胜诉概率与风险"的可交付结论。比对结论直接决定后续路径选择（S4–S7）。

## Workflow

1. **确定比对框架**：先识别权利类型（发明/实用新型/外观设计专利、商标、著作权、商业秘密、或多项竞合），按对应章节读取规则：
   - 专利（发明/实用新型）：`patent-comparison.md`
   - 专利（外观设计）：`patent-comparison.md`（外观章节）
   - 商标：`trademark-comparison.md`
   - 著作权：`copyright-comparison.md`
   - 商业秘密：`trade-secret-comparison.md`
2. **固定比对对象**：明确被控对象（产品/技术方案/标识/作品/信息载体）及来源证据（S3 产出的证据包），仅以证据支持的形态做比对，不做无据推测。
3. **逐项比对**：
   - 按权利文本的技术特征/标识要素/独创性表达/密点逐项分解，与被控对象对应项一一比对。
   - 结论分档：落入保护范围 / 不落入 / 存疑（需进一步证据或鉴定）。
4. **抗辩预判**：主动列出被告可能主张的抗辩并评估成立可能：现有技术/设计、先用权、合法来源、权利用尽、不视为侵权（临时过境/科研实验/药品行政审批）、合理使用、商标正当使用/描述性使用、在先权利、不相似不混淆等。
5. **风险与胜诉评估**：综合侵权成立可能性、权利稳定性（S0 核查结果）、被告抗辩强度、管辖与证据状况，给出"高/中/低"胜诉可能性和主要风险点。
6. **输出比对分析报告**：报告结构固定：权利基础 → 被控对象 → 比对表（特征/要素逐项）→ 结论 → 抗辩预判 → 风险评估 → 建议路径。报告用表格呈现比对项，禁止只给结论不给依据。

## Output Standards

- 每一比对项都必须给出"被控对象对应内容 + 比对理由 + 结论"，可复核。
- 区分"侵权成立可能性高/中/低"与"证据支持程度"，不得混为一谈。
- 结论不确定时明确标注"存疑及所需补充证据"，不强行下结论。

## Resources

- `patent-comparison.md`：发明/实用新型全面覆盖与等同原则、外观设计相同/近似判断。
- `trademark-comparison.md`：商标相同/近似、商品类似、混淆可能性。
- `copyright-comparison.md`：接触+实质性相似、合理使用边界。
- `trade-secret-comparison.md`：三要件、密点对应、侵权行为类型。

## 作者

本技能由 **知产刀客 · SamjoeYang** 设计并维护。
