---
name: ip-infringement-discovery
display_name: 侵权线索发现
display_name_en: IP Infringement Lead Discovery
description: 知识产权侵权线索发现与初判。用于多渠道（电商平台、线下市场、展会、社交媒体、海关、域名）收集疑似侵权线索、锁定侵权主体及其生产/销售/进出口链条、按权利类型做初步判断并分级排序。当用户需要"找侵权线索""查谁在仿冒我""发现疑似侵权帮我评估"时使用。Also usable in English when the user mentions finding IP infringement clues, detecting counterfeits, infringement discovery, suspect monitoring.
description_zh: 知识产权侵权线索发现与初判：多渠道（电商平台、线下市场、展会、社交媒体、海关、域名）收集疑似侵权线索，锁定侵权主体及其生产/销售/进出口链条，按权利类型做初步判断并分级排序。
description_en: 'IP infringement lead discovery and triage: collects suspected-infringement leads across e-commerce, offline markets, trade fairs, social media, customs and domains; identifies infringers and their production/sales/import-export chains; makes a preliminary assessment by right type and prioritizes leads.'
version: 1.0.1
author: SamjoeYang - 上海不丁网络科技有限公司
license: MIT
agent_created: true
---

# 侵权发现与线索初判（S1）

## Overview

本技能把"疑似侵权"从零散信息变成可进入比对阶段的结构化线索：先确认线索来源与真实性，再锁定侵权主体链条，最后按权利类型初判并分级，输出线索台账。

## Workflow

1. **确认权利基础**：先引用 S0 `ip-rights-audit` 产出的权利清单；若尚未建立，先要求用户提供权利凭证，避免对无效/过期权利做无用发现。
2. **收集线索**：按 `discovery-channels.md` 的渠道清单系统检索（电商平台关键词/图片、线下与展会、社媒、海关、域名），逐条记录发现时间、渠道、链接、截图存档。
3. **锁定主体链**：对每条线索做主体溯源：
   - 线上：店铺主体（营业执照信息）、发货地、品牌授权情况、销量与价格（判断是否明显低于正常价）、是否支持一件代发。
   - 线下/展会：展位主体、生产商标识、包装厂名厂址。
   - 出口：报关信息、货代线索（如涉及跨境）。
   - 尝试识别完整链条：销售终端 → 批发 → 生产/组装 → 原材料（用于后续选择维权对象与路径）。
4. **初判权利类型**：对照权利清单判断疑似侵犯的权利类型，典型特征：
   - 专利：技术方案/结构/外观与权利人或其正品高度一致但非官方渠道。
   - 商标：相同或近似标识使用在相同/类似商品上，价格异常、包装仿冒。
   - 著作权：盗版书/软件/影视/图片/文案/字体，整段或实质部分复制。
   - 商业秘密：前员工/合作方竞业产品与自研产品高度雷同，或配方/客户名单泄露。
   - 不正当竞争：仿冒包装装潢、虚假宣传、商业诋毁（作为并列项提示）。
5. **线索分级**：按证据强度×影响程度打级：
   - A 级（优先处理）：证据明显（可直接购买取证）、销量/规模大、影响核心市场。
   - B 级（常规处理）：证据较明确、规模中等。
   - C 级（观察）：疑似但证据不足，列入监测继续观察。
6. **输出线索台账**：按 `discovery-channels.md` 的台账模板整理，标记每条线索的取证建议（购买取证/公证/存证），交接给 S3 证据固定或 S2 侵权比对。

## Output Standards

- 每条线索必须包含：发现日期、渠道、主体信息、链接/位置、初步侵权类型、分级、下一步动作。
- 区分"已核实主体信息"与"主体待确认"，禁止把猜测写成事实。
- 对销量、价格等数据标注来源与采集时间。

## Resources

- `discovery-channels.md`：渠道检索方法、主体溯源要点、线索分级标准。
- 可与 S2 `ip-infringement-analysis`、S3 `ip-evidence-collection` 衔接使用。

## 作者

本技能由 **知产刀客 · SamjoeYang** 设计并维护。
