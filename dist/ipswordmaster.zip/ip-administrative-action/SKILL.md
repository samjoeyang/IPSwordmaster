---
name: ip-administrative-action
display_name: 行政保护维权
display_name_en: Administrative IP Enforcement
description: 知识产权行政保护路径：专利侵权纠纷行政裁决、商标侵权行政查处、著作权行政处罚、知识产权海关保护。用于选择行政维权路径、准备请求/举报/处罚材料、跟进行政程序时限、申请海关备案与扣留侵权嫌疑货物。当用户需要"行政裁决""找市场监管局/知识产权局投诉""海关扣货""行政查处假货"时使用。Also usable in English when the user mentions administrative IP enforcement, patent infringement adjudication, trademark raid, customs seizure, IP administrative penalty.
description_zh: 知识产权行政保护路径：专利侵权纠纷行政裁决、商标侵权行政查处、著作权行政处罚、知识产权海关保护。用于选择行政维权路径、准备请求/举报/处罚材料、跟进行政程序时限、申请海关备案与扣留侵权嫌疑货物。
description_en: 'Administrative IP enforcement: patent-infringement administrative adjudication, trademark administrative investigation, copyright administrative penalties, and IP customs protection. Helps choose the administrative route, prepare requests/complaints/penalty materials, track statutory deadlines, and apply for customs recordal and detention of suspected-infringing goods.'
version: 1.0.0
author: SamjoeYang - 上海不丁网络科技有限公司
license: MIT
agent_created: true
---

# 行政保护（S5）

## Overview

行政路径特点：周期短、成本低、不需要律师函前置，但行政决定一般只确认侵权并责令停止，不直接判赔（赔偿需另行民事诉讼）。本技能覆盖四条行政通道的选择、材料与时限。

## Workflow

1. **路径选择**：根据权利类型与诉求选通道（可并行）：
   - 专利侵权纠纷 → 管理专利工作的部门（知识产权局/市场监管部门）行政裁决。
   - 商标侵权 → 市场监督管理部门查处（责令停止、没收销毁、罚款）。
   - 著作权侵权 → 版权局/文化执法部门行政处罚。
   - 进出口环节 → 海关知识产权保护（备案+扣留）。
   - 商业秘密/不正当竞争 → 市场监管部门查处。
2. **专利行政裁决**：按 `administrative-adjudication.md`：
   - 请求条件：请求人是专利权人或利害关系人、有明确被请求人、有明确请求事项与事实理由、属受案范围与管辖。
   - 材料：请求书 + 主体资格证明（身份证/营业执照及法定代表人证明）+ 专利证书及年费凭证 + 侵权证据。
   - 程序：立案审核（3 名以上单数执法）→ 受理通知（受理后 5 个工作日内送达请求人）→ 答辩通知（立案后 5 个工作日内送达被请求人）→ 口头审理 → 作出行政裁决。
   - 调查取证：因客观原因不能自行收集证据时，可申请管理专利工作的部门签发调查通知书调查取证。
3. **商标/著作权行政查处**：向侵权行为地市场监督管理部门/版权执法部门提交举报材料：主体资格、权利证明、侵权线索与证据（衔接 S3 证据包）、诉求（查处、责令停止、罚款）。执法部门依职权调查、抽样取证、登记保存涉嫌侵权物品。
4. **海关保护**：按 `customs-protection.md`：
   - 首选备案（S0 已建）→ 海关依职权中止放行 → 通知权利人 → 3 个工作日内申请扣留+担保。
   - 未备案：发现侵权嫌疑货物即将进出口，直接向进出境地海关申请扣留（申请书+权利证明+明显侵权证据+担保）。
5. **跟进与衔接**：行政裁决/处罚决定下达后：
   - 对行政裁决不服可提起行政诉讼；对方不履行可申请法院强制执行。
   - 行政确认侵权后，可另行提起民事诉讼索赔（裁决书可作为侵权认定证据）。

## Output Standards

- 材料清单逐项核对，主体资格、权利证明、侵权证据三类缺一不可。
- 时限（受理通知 5 个工作日、答辩通知 5 个工作日、海关 3 个工作日申请扣留等）如实提示，不模糊化。
- 明确告知行政路径"可责令停止+处罚，但不直接判赔"的边界，引导用户判断是否需要诉讼衔接。

## Resources

- `administrative-adjudication.md`：专利行政裁决与商标/著作权查处要点。
- `customs-protection.md`：海关备案、依职权/依申请扣留流程与担保。

## 作者

本技能由 **知产刀客 · SamjoeYang** 设计并维护。
